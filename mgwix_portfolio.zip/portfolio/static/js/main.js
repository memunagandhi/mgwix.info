/* MGWix Portfolio — main.js */

// ── CUSTOM CURSOR ──────────────────────────
const cursor    = document.getElementById('cursor');
const cursorDot = document.getElementById('cursorDot');
let mx = 0, my = 0, cx = 0, cy = 0;

document.addEventListener('mousemove', e => { mx = e.clientX; my = e.clientY; });

function animateCursor() {
  cx += (mx - cx) * 0.15;
  cy += (my - cy) * 0.15;
  if(cursor) { cursor.style.left = cx + 'px'; cursor.style.top = cy + 'px'; }
  if(cursorDot) { cursorDot.style.left = mx + 'px'; cursorDot.style.top = my + 'px'; }
  requestAnimationFrame(animateCursor);
}
animateCursor();

document.querySelectorAll('a, button, .skill-card, .project-card, input, select, textarea').forEach(el => {
  el.addEventListener('mouseenter', () => cursor?.classList.add('hover'));
  el.addEventListener('mouseleave', () => cursor?.classList.remove('hover'));
});

// ── NAV SCROLL ─────────────────────────────
const nav = document.getElementById('nav');
window.addEventListener('scroll', () => {
  nav?.classList.toggle('scrolled', window.scrollY > 50);
});

// ── HAMBURGER ──────────────────────────────
const hamburger  = document.getElementById('hamburger');
const mobileMenu = document.getElementById('mobileMenu');
hamburger?.addEventListener('click', () => {
  mobileMenu?.classList.toggle('open');
});
document.querySelectorAll('.mm-link').forEach(l => {
  l.addEventListener('click', () => mobileMenu?.classList.remove('open'));
});

// ── REVEAL ON SCROLL ───────────────────────
const revealObserver = new IntersectionObserver(entries => {
  entries.forEach(e => { if(e.isIntersecting) e.target.classList.add('visible'); });
}, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });
document.querySelectorAll('.reveal').forEach(el => revealObserver.observe(el));

// ── COUNTER ANIMATION ──────────────────────
const counterObserver = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if(e.isIntersecting) {
      const el     = e.target;
      const target = parseInt(el.dataset.target);
      const dur    = 1600;
      const start  = performance.now();
      const tick   = now => {
        const p = Math.min((now - start) / dur, 1);
        const v = 1 - Math.pow(1 - p, 3);
        el.textContent = Math.floor(v * target);
        if(p < 1) requestAnimationFrame(tick);
        else el.textContent = target;
      };
      requestAnimationFrame(tick);
      counterObserver.unobserve(el);
    }
  });
}, { threshold: 0.5 });
document.querySelectorAll('.metric-num').forEach(el => counterObserver.observe(el));

// ── CONTACT FORM ───────────────────────────
document.getElementById('contactForm')?.addEventListener('submit', async function(e) {
  e.preventDefault();
  const btn     = document.getElementById('submitBtn');
  const btnText = document.getElementById('btnText');
  const success = document.getElementById('formSuccess');
  const errDiv  = document.getElementById('formError');

  btn.disabled = true;
  btnText.textContent = 'Sending...';
  errDiv.style.display = 'none';

  const data = {
    name:    document.getElementById('name').value,
    email:   document.getElementById('email').value,
    service: document.getElementById('service').value,
    budget:  document.getElementById('budget').value,
    message: document.getElementById('message').value,
  };

  try {
    const res    = await fetch('/submit-contact', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    const result = await res.json();
    if(result.success) {
      success.style.display = 'flex';
      this.reset();
      btnText.textContent = 'Message Sent ✓';
    }
  } catch(err) {
    errDiv.textContent  = 'Something went wrong. Please email me directly at hello@mgwix.online';
    errDiv.style.display = 'block';
    btn.disabled = false;
    btnText.textContent = 'Send Message';
  }
});

// ── SMOOTH ANCHOR SCROLL ───────────────────
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const target = document.querySelector(a.getAttribute('href'));
    if(target) {
      e.preventDefault();
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
});

// ── PARALLAX GRID ──────────────────────────
window.addEventListener('scroll', () => {
  const y = window.scrollY;
  const grid = document.querySelector('.hero-grid-lines');
  if(grid) grid.style.transform = `translateY(${y * 0.08}px)`;
});
